#!/usr/bin/env python3
import sys
import urllib.request
import urllib.error
import concurrent.futures
import json
import time
import ssl
import re
from datetime import datetime

# Reconfigure stdout to support unicode graphics on Windows terminal
try:
    sys.stdout.reconfigure(encoding='utf-8')
except AttributeError:
    pass

# Bypass SSL verification
try:
    ssl_context = ssl._create_unverified_context()
except AttributeError:
    ssl_context = None

# Try importing ReportLab for PDF exports
try:
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

# ANSI colors for C2 style
GREEN = "\033[38;5;82m"
RED = "\033[38;5;129m"     # Purple color (Lila)
CYAN = "\033[38;5;135m"    # Soft Purple
YELLOW = "\033[38;5;226m"
RESET = "\033[0m"
GRAY = "\033[38;5;244m"

ASCII_ART = f"""{RED}
  ▄   ▄▄▄▄   ▄▄▄  ▄▄▄   ▄▄▄  ▄▄ 
  ▀██████▀  █▀██  ██   █▀██  ██ 
    ██   ▄    ██  ██     ██  ██ 
    ██  ██    ██████     ██  ██ 
    ██  ██    ██  ██     ██  ██ 
    ▀█████  ▀██▀  ▀██▄   ▀█████▄
    ▄   ██                      
    ▀████▀ 
                     
     Ghul's Username Radar v0.beta{RESET}"""

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
}

# Fallback sites if online DB is unavailable (includes custom Doxbin & Discord targets)
FALLBACK_PLATFORMS = {
    "GitHub": {
        "url": "https://github.com/{}",
        "errorType": "status_code"
    },
    "Reddit": {
        "url": "https://www.reddit.com/user/{}",
        "errorType": "message",
        "errorMsg": "page not found"
    },
    "Twitch": {
        "url": "https://www.twitch.tv/{}",
        "errorType": "status_code"
    },
    "YouTube": {
        "url": "https://www.youtube.com/@{}",
        "errorType": "status_code"
    },
    "Steam": {
        "url": "https://steamcommunity.com/id/{}",
        "errorType": "message",
        "errorMsg": "The specified profile could not be found"
    },
    "Spotify": {
        "url": "https://open.spotify.com/user/{}",
        "errorType": "status_code"
    },
    "Pinterest": {
        "url": "https://www.pinterest.com/{}/",
        "errorType": "message",
        "errorMsg": "User not found"
    },
    "Doxbin": {
        "url": "https://doxbin.org/user/{}",
        "errorType": "message",
        "errorMsg": "User not found"
    },
    "Discord": {
        "url": "https://discord.com/users/{}",
        "errorType": "status_code"
    }
}

def get_creation_date(platform, username):
    """
    Attempts to retrieve the account creation date for major platforms.
    """
    if platform.lower() == "github":
        try:
            req = urllib.request.Request(f"https://api.github.com/users/{username}", headers=HEADERS)
            with urllib.request.urlopen(req, timeout=5, context=ssl_context) as response:
                data = json.loads(response.read().decode())
                created = data.get("created_at", "")
                if created:
                    return f"Created: {created.split('T')[0]}"
        except Exception:
            pass

    elif platform.lower() == "reddit":
        try:
            headers = {"User-Agent": f"GHU-OSINT-Tool/v0.beta ({username})"}
            req = urllib.request.Request(f"https://www.reddit.com/user/{username}/about.json", headers=headers)
            with urllib.request.urlopen(req, timeout=5, context=ssl_context) as response:
                data = json.loads(response.read().decode())
                created_utc = data.get("data", {}).get("created_utc")
                if created_utc:
                    dt = datetime.utcfromtimestamp(created_utc)
                    return f"Created: {dt.strftime('%Y-%m-%d')}"
        except Exception:
            pass

    return "Created: N/A"

def check_platform(name, info, username):
    url_template = info.get("url", "")
    target_url = url_template.replace("{}", username).replace("{username}", username)
    error_type = info.get("errorType", "status_code")
    error_msg = info.get("errorMsg", "")
    error_url = info.get("errorUrl", "")

    try:
        req = urllib.request.Request(target_url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=3, context=ssl_context) as response:
            final_url = response.geturl()
            if error_type == "response_url" and error_url in final_url:
                return name, False, target_url, "Created: N/A"
                
            code = response.getcode()
            if code == 200:
                html = response.read().decode('utf-8', errors='ignore')
                
                # Check message type or absence string list
                if error_type == "message" and error_msg:
                    # Support multiple error message checks
                    msgs = error_msg if isinstance(error_msg, list) else [error_msg]
                    for msg in msgs:
                        if msg.lower() in html.lower():
                            return name, False, target_url, "Created: N/A"
                
                if "page not found" in html.lower() or "404 not found" in html.lower():
                    return name, False, target_url, "Created: N/A"
                    
                creation_date = get_creation_date(name, username)
                return name, True, target_url, creation_date
            return name, False, target_url, "Created: N/A"
    except urllib.error.HTTPError:
        return name, False, target_url, "Created: N/A"
    except Exception:
        return name, False, target_url, "Created: N/A"

def fetch_databases():
    print(f"{CYAN}[*] Fetching online databases (Sherlock, Maigret, WhatsMyName & IANA TLDs)...{RESET}")
    platforms = {}
    
    # Pre-add Discord and Doxbin
    platforms["Doxbin"] = FALLBACK_PLATFORMS["Doxbin"]
    platforms["Discord"] = FALLBACK_PLATFORMS["Discord"]

    # 1. Fetch Sherlock
    sherlock_urls = [
        "https://cdn.jsdelivr.net/gh/sherlock-project/sherlock/sherlock/resources/data.json",
        "https://raw.githubusercontent.com/sherlock-project/sherlock/master/sherlock/resources/data.json"
    ]
    for url in sherlock_urls:
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=5, context=ssl_context) as response:
                data = json.loads(response.read().decode())
                for name, details in data.items():
                    if "url" in details:
                        platforms[name] = details
                break
        except Exception:
            continue

    # 2. Fetch Maigret (~3000 websites!)
    maigret_urls = [
        "https://cdn.jsdelivr.net/gh/soxoj/maigret/maigret/resources/data.json",
        "https://raw.githubusercontent.com/soxoj/maigret/main/maigret/resources/data.json"
    ]
    for url in maigret_urls:
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=5, context=ssl_context) as response:
                data = json.loads(response.read().decode())
                sites_data = data.get("sites", {})
                for name, details in sites_data.items():
                    if "url" in details and name not in platforms:
                        error_type = details.get("checkType", "status_code")
                        absence_strs = details.get("absenceStrs", [])
                        
                        info = {
                            "url": details["url"],
                            "errorType": error_type,
                            "errorMsg": absence_strs,
                            "errorUrl": details.get("error_url", "")
                        }
                        platforms[name] = info
                break
        except Exception:
            continue

    # 3. Fetch WhatsMyName (~500+ websites!)
    wmn_urls = [
        "https://raw.githubusercontent.com/WebBreacher/WhatsMyName/main/wmn-data.json"
    ]
    for url in wmn_urls:
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=5, context=ssl_context) as response:
                data = json.loads(response.read().decode())
                for item in data.get("account_types", []):
                    name = item.get("name")
                    uri = item.get("uri_check")
                    if name and uri and name not in platforms:
                        url_clean = uri.replace("{account}", "{}")
                        platforms[name] = {
                            "url": url_clean,
                            "errorType": "message" if item.get("regex_check") else "status_code",
                            "errorMsg": item.get("regex_check", "")
                        }
                break
        except Exception:
            continue

    # 4. Fetch IANA TLD list (1500+ domain extensions!)
    tlds = []
    try:
        tld_url = "https://data.iana.org/TLD/tlds-alpha-by-domain.txt"
        req = urllib.request.Request(tld_url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=5, context=ssl_context) as response:
            lines = response.read().decode().splitlines()
            for line in lines:
                if line and not line.startswith("#"):
                    tlds.append(line.strip().lower())
    except Exception:
        tlds = ["com", "net", "org", "co", "io", "me", "info", "biz", "us", "uk", "de", "fr", "ru", "xyz", "space", "online", "tech", "site", "website"]

    for tld in tlds:
        platforms[f"Personal Domain (.{tld})"] = {
            "url": f"http://{{}}.{tld}",
            "errorType": "status_code"
        }

    if platforms:
        print(f"{GREEN}[+] Loaded {len(platforms)} platforms successfully (including all {len(tlds)} IANA TLD extensions)!{RESET}")
        return platforms
        
    print(f"{YELLOW}[!] Could not fetch online DBs. Using fallback list.{RESET}")
    return FALLBACK_PLATFORMS

def categorize_results(results):
    categories = {
        "Domains / Personal Websites": [],
        "Developer / Coding / Tech": [],
        "Gaming / Streaming": [],
        "Social Media / Chat": [],
        "Forums / Underground": [],
        "Others / Miscellaneous": []
    }
    
    for name, url, creation in results:
        name_lower = name.lower()
        url_lower = url.lower()
        
        if "domain" in name_lower or "personal domain" in name_lower:
            categories["Domains / Personal Websites"].append((url, creation))
        elif any(k in name_lower or k in url_lower for k in ["github", "gitlab", "bitbucket", "stackoverflow", "pypi", "npm", "dev.to", "code", "git", "hackerrank", "leetcode", "coder"]):
            categories["Developer / Coding / Tech"].append((url, creation))
        elif any(k in name_lower or k in url_lower for k in ["steam", "twitch", "roblox", "youtube", "xbox", "playstation", "chess", "nintendo", "epicgames", "origin", "gaming"]):
            categories["Gaming / Streaming"].append((url, creation))
        elif any(k in name_lower or k in url_lower for k in ["reddit", "twitter", "x.com", "instagram", "facebook", "snapchat", "telegram", "discord", "pinterest", "tiktok", "medium", "tumblr", "linktree", "linktr"]):
            categories["Social Media / Chat"].append((url, creation))
        elif any(k in name_lower or k in url_lower for k in ["doxbin", "hack", "forum", "underground", "raid", "leak", "exploit", "null", "cracked"]):
            categories["Forums / Underground"].append((url, creation))
        else:
            categories["Others / Miscellaneous"].append((url, creation))
            
    return categories

def export_results(username, categorized_results):
    print(f"\n{CYAN}[?] Do you want to export results to PDF, TXT, and JSON? (y/n): {RESET}", end="")
    try:
        choice = input().strip().lower()
    except Exception:
        choice = "n"
        
    if choice != 'y':
        return
        
    # TXT Export
    try:
        txt_path = f"GHU_{username}_report.txt"
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(f"=== GHU OSINT REPORT FOR {username.upper()} ===\n")
            f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            for cat, items in categorized_results.items():
                if items:
                    f.write(f"[{cat.upper()}]\n")
                    for url, creation in items:
                        f.write(f"  - {url} [{creation}]\n")
                    f.write("\n")
        print(f"{GREEN}[+] Exported TXT: {txt_path}{RESET}")
    except Exception as e:
        print(f"{RED}[!] Failed to export TXT: {e}{RESET}")

    # JSON Export
    try:
        json_path = f"GHU_{username}_report.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(categorized_results, f, indent=4)
        print(f"{GREEN}[+] Exported JSON: {json_path}{RESET}")
    except Exception as e:
        print(f"{RED}[!] Failed to export JSON: {e}{RESET}")

    # PDF Export
    if REPORTLAB_AVAILABLE:
        try:
            pdf_path = f"GHU_{username}_report.pdf"
            doc = SimpleDocTemplate(pdf_path, pagesize=letter)
            styles = getSampleStyleSheet()
            
            title_style = ParagraphStyle(
                'TitleStyle',
                parent=styles['Heading1'],
                textColor=colors.HexColor("#7A1FA2"),
                fontSize=20,
                spaceAfter=15
            )
            h2_style = ParagraphStyle(
                'H2Style',
                parent=styles['Heading2'],
                textColor=colors.HexColor("#4A148C"),
                fontSize=14,
                spaceBefore=10,
                spaceAfter=6
            )
            body_style = ParagraphStyle(
                'BodyStyle',
                parent=styles['Normal'],
                fontSize=10,
                spaceAfter=4
            )
            
            story = []
            story.append(Paragraph(f"GHU OSINT Target Report: {username.upper()}", title_style))
            story.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", body_style))
            story.append(Spacer(1, 15))
            
            for cat, items in categorized_results.items():
                if items:
                    story.append(Paragraph(cat, h2_style))
                    for url, creation in items:
                        story.append(Paragraph(f"• <a href='{url}'>{url}</a> ({creation})", body_style))
                    story.append(Spacer(1, 10))
                    
            doc.build(story)
            print(f"{GREEN}[+] Exported PDF: {pdf_path}{RESET}")
        except Exception as e:
            print(f"{RED}[!] Failed to export PDF: {e}{RESET}")
    else:
        print(f"{YELLOW}[!] PDF export skipped (reportlab not installed). Run GHU.bat to auto-install it.{RESET}")

def main():
    try:
        print(ASCII_ART)
        
        if len(sys.argv) > 1:
            username = sys.argv[1]
        else:
            try:
                username = input(f"{RED}GHU >{RESET}").strip()
            except KeyboardInterrupt:
                print("\nAborting mission.")
                sys.exit(0)
                
        if not username:
            print(f"{RED}[!] Error: Username cannot be empty.{RESET}")
            sys.exit(1)
            
        platforms = fetch_databases()
        
        print(f"\n{CYAN}[*] Scanning target: {username.upper()}{RESET}")
        found_results = []
        raw_results = []
        
        # Run requests concurrently
        with concurrent.futures.ThreadPoolExecutor(max_workers=120) as executor:
            futures = {
                executor.submit(check_platform, name, info, username): name
                for name, info in platforms.items()
            }
            for future in concurrent.futures.as_completed(futures):
                try:
                    name, found, url, creation = future.result()
                    if found:
                        found_results.append((url, creation))
                        raw_results.append((name, url, creation))
                        print(f" {GREEN}{{/]{RESET} Found: {url}")
                except Exception:
                    pass

        # Categorize
        categorized = categorize_results(raw_results)

        # Draw the dynamic box matching the requested layout
        print("\n")
        formatted_lines = []
        
        for category, items in categorized.items():
            if items:
                formatted_lines.append(f" --- {category.upper()} ---")
                for url, creation in items:
                    formatted_lines.append(f"  {{/] {url} [{creation}]")
            
        max_len = max(len(line) for line in formatted_lines) if formatted_lines else 0
        width = max(max_len + 4, 36)
        
        # Top line of result box
        print("_" * width)
        header_text = "RESULT"
        print(f"|{header_text.center(width - 2)}|")
        print(f"|{' ' * (width - 2)}|")
        
        if formatted_lines:
            for line in formatted_lines:
                padded_line = line.ljust(width - 2)
                # Replace the {/] indicator with the colored version
                colored_line = padded_line.replace("{/]", f"{GREEN}{{/]{RESET}")
                print(f"|{colored_line}|")
        else:
            # Standard empty lines if no results
            for _ in range(3):
                print(f"|{' ' * (width - 2)}|")
                
        print(f"|{' ' * (width - 2)}|")
        print(f"|{'_' * (width - 2)}|")
        
        # Run Export Flow
        export_results(username, categorized)
        
    finally:
        print("discord.gg/5xj3g5yCaJ")
        print("JOIN FOR MORE TOOL'S")

if __name__ == "__main__":
    main()
