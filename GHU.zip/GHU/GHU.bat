@echo off
title GHU - Ghul's Username Radar
color 0D

:: Ensure compatibility for Windows 10 & 11 console UTF-8 output
chcp 65001 >nul

echo ====================================================
echo             GHU Windows 10/11 Setup
echo ====================================================
echo Checking Python installation...

:: Check if python is working and not just the Microsoft Store shortcut
python -c "import sys" >nul 2>&1
if %errorlevel% neq 0 (
    :: Try 'py' launcher which is common on Windows
    py -c "import sys" >nul 2>&1
    if %errorlevel% eq 0 (
        set PYTHON_CMD=py
        goto run
    )
    
    echo [!] Python is not installed or the Windows Store shortcut intercepted it.
    echo [*] Downloading Python 3.10 Installer for Windows 10/11...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe' -OutFile '%temp%\python_installer.exe'"
    
    echo [*] Installing Python. Please authorize the installation...
    start /wait "" "%temp%\python_installer.exe" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
    del "%temp%\python_installer.exe"
    
    :: Refresh PATH for current session
    refreshenv >nul 2>&1
    
    :: Final verify
    python -c "import sys" >nul 2>&1
    if %errorlevel% neq 0 (
        echo [!] Installation failed or system requires a reboot to update PATH.
        echo [!] Please manually install Python from python.org or the Microsoft Store.
        pause
        exit /b 1
    )
)

set PYTHON_CMD=python

:run
echo [*] Checking dependencies...
%PYTHON_CMD% -c "import reportlab" >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Installing reportlab library for PDF export...
    %PYTHON_CMD% -m pip install reportlab >nul 2>&1
)
echo [*] Launching GHU Username Radar...
cls
%PYTHON_CMD% "%~dp0ghu.py" %*
pause
